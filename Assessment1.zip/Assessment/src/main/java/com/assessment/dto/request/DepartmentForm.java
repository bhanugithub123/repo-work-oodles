package com.assessment.dto.request;

import lombok.Data;

@Data
public class DepartmentForm {
    private String departmentName;
}
