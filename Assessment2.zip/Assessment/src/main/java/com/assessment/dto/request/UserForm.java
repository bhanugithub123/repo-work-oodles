package com.assessment.dto.request;

import lombok.Data;

@Data
public class UserForm {

    private String userName;
    private String password;

}
